import numpy as np
from numba import njit
from single import Qd, Cd, FS, SPC, demod
@njit(cache=True)
def runm(xs,VB,cj1,cj2,M,vj,cfix,Qc0):
    n=len(xs); out=np.empty(n); c=VB
    for i in range(n):
        a=xs[i]
        for _ in range(40):
            f=Qd(c-a,cj1,M,vj)+Qd(c,cj2,M,vj)-Qc0
            d=f/(Cd(c-a,cj1,M,vj)+Cd(c,cj2,M,vj)); c-=d
            if abs(d)<1e-14: break
        out[i]=Qd(c,cj2,M,vj)-cfix*a
    return out
cj=78e-12; M=0.45; vj=0.7
Cpair=lambda V: Cd(V,cj,M,vj)/2
Cfix=Cpair(12.0)
def meas(VB,v,mis):
    n=int(4/1000*FS); t=np.arange(n)/FS; s=np.where((np.arange(n)%SPC)<SPC//2,1.0,-1.0)
    x=v*np.sqrt(2)*np.sin(2*np.pi*1000*t)*s
    Qc0=Qd(VB,cj*(1+mis),M,vj)+Qd(VB,cj,M,vj)
    y=demod(runm(x,VB,cj*(1+mis),cj,M,vj,Cfix,Qc0)); h=np.abs(np.fft.rfft(y)[[4*k for k in range(1,10)]])
    return h[0], np.sqrt(np.sum(h[1:]**2))/h[0]
from scipy.optimize import brentq
G=lambda VB: Cpair(VB)-Cfix
print(f"v2: single-diode pair, C_fixed = {Cfix*1e12:.2f} pF (null at 12 V); 'v' = signal at the pair (input/2)")
for gdb in [0,-6,-12,-20,-25]:
    VB=1.5 if gdb==0 else brentq(lambda u: 20*np.log10(G(u)/G(1.5))-gdb,1.5,11.99)
    r=[]
    for mis in [0,0.01]:
        for v in [0.5,1.0]:
            a,d=meas(VB,v,mis); r.append(f"{'1% mis' if mis else 'matched'} {v}V {d*100:.4f}%")
    print(f"  {gdb:4d} dB (VB {VB:5.2f} V): "+" | ".join(r))
