# Varactor half-bridge gain cell: prototype v2 (single varactor pair)

One anti-series varactor pair (D1, D2) is balanced against a fixed C0G capacitor (C40 with trimmer CT3). It runs on a 102.4 kHz carrier into a charge amplifier, followed by a synchronous, gated demodulator.
Each cell gives 0 dB to about -25 dB of gain. For more reduction, chain two cells.

This is an unverified design: build it and measure it. The numbers below come from simulation.

## What changed from v1
| | v1 (full bridge) | v2 (half-bridge) |
|---|---|---|
| Varactors | 8 (two pairs, two in parallel) | **2 (one pair)** |
| Fixed side | second varactor pair + bias network + 100 MΩ | **8.2 pF C0G + 0.5–3 pF trimmer** |
| Op-amp ICs | 6 | **5** |
| Range per cell | about 40 dB | **about 25 dB (chain two for more)** |
| Parts | 112 | **98** |

## Simulated performance
Ideal surrounding parts, MV2109-class diodes, 1 kHz. Input level is twice the signal at the pair.

| Gain | VB | THD at 1 Vrms in | THD at 2 Vrms in |
|---|---|---|---|
| 0 dB | 1.5 V | 0.009% | 0.036% |
| -6 dB | 3.8 V | 0.003% | 0.013% |
| -12 dB | 6.4 V | 0.002% | 0.008% |
| -20 dB | 9.2 V | 0.002% | 0.009% |
| -25 dB | 10.3 V | 0.003% | 0.012% |

- **Distortion is almost entirely 3rd harmonic** and rises with level. It's highest at maximum gain, because the bias voltage is lowest there.
- **Pair mismatch:** a 1% mismatch inside the pair had no measurable effect, so CT1 and CT2 are optional (not fitted by default).
- **Temperature drift** (varactor against the C0G capacitor), assuming a 300 ppm/K varactor tempco: about 0.005 dB/K at 0 dB, 0.009 dB/K at -10 dB, 0.023 dB/K at -20 dB.
- **Effects not included in this table**, all estimated from the earlier v1 work:
  - **Resistor bias feed:** with the 10 MΩ setting, expect extra distortion at the deep end. The 100 MΩ setting is cleaner but slower (about 15 ms gain response instead of about 1.5 ms).
  - **Noise:** about -104 dBu.

## Signal path
1. **Input (U1).** Makes +x/2 (XP) and -x/2 (XN).
2. **Modulator (U7, U8).** DG419 switches chop at CLK_S. The XA node feeds the fixed capacitor; the XB node feeds the varactor pair.
3. **Half-bridge.**
   - The pair's centre CB is biased by VB through 10 MΩ or 100 MΩ (JP2).
   - Output charge is proportional to (C_pair(VB) - C_fixed)·x.
   - Gain is highest at VB ≈ 1.5 V and falls as VB rises. The null is near VB ≈ 12 V, set by CT3.
4. **Charge amplifier (U2A, OPA1656).** Cf = 6.8 pF, with 100 MΩ for DC.
5. **Demodulator.** U2B inverts the charge-amp output, U9 is the synchronous switch, U10 is the gated hold (JP3 selects its polarity). Then a 30 kHz Butterworth (U3B, U4A) and makeup gain (U4B).
6. **Control (U5).** VB = 2·CV + 2·VOFF. CV comes from J4 or the manual pot RV2, selected by JP1. RV3 sets VB = 1.5 V at CV = 0.

## Bring-up
1. **Power.** Apply ±15 V, check +5 V, then fit the ICs.
2. **Timing.** TP1 should show 102.4 kHz. TP2 (GATE) should be high for about 2.1 µs late in each 4.88 µs half-period.
3. **JP3 (hold polarity).** Feed a 1 kHz tone. Pick the JP3 position where TP6 (HOLD) is a clean staircase with no spikes at the carrier edges.
4. **Minimum bias.** Set CV = 0 (JP1 on manual, RV2 at minimum) and adjust RV3 for VB (TP9) = 1.5 V.
5. **Null.** Set CV = 5 V (VB ≈ 11.5 V) and adjust CT3 until the output is about 25 dB below its level at CV = 0.
6. **Optional trim.** Fit CT1 or CT2 and trim for minimum THD at maximum reduction.
7. **Calibrate.** Record gain against CV at a few points. That table is what the sidechain uses.

## Chaining for more reduction
Connect cell 1 OUT to cell 2 IN, and split the requested reduction between the cells: for example, up to 25 dB on cell 1 first, then cell 2.
Each cell keeps its own clock; you can also share one oscillator and counter between the two boards.
Noise is set by the last cell, about -104 dBu.

## Construction notes
These are unchanged from v1:
- Keep the high-impedance nodes **VG** and **CB** off solderless breadboard. Use PTFE standoffs or air wiring and clean off the flux.
- Use a matched (within 1%), thermally coupled MV2109-class pair. Check availability and leakage (below 100 pA wanted).
- Verify the DG419 and oscillator pinouts against their datasheets.
- The OPA1656 is SOIC-only; use an adapter.
