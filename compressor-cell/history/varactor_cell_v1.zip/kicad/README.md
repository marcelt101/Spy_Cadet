# Varactor-bridge gain cell: prototype v1

Carrier-fed, anti-series varactor bridge with a charge amplifier and a synchronous demodulator.
This is an unverified design: build it, measure it, and treat the numbers below as simulation estimates.

## Files
| File | What it is |
|---|---|
| `varactor_cell.kicad_pro` / `.kicad_sch` | KiCad 7 project and schematic (opens in KiCad 7 or 8) |
| `varactor_cell.pdf` | Printable schematic (A1) |
| `BOM.csv` | Bill of materials |
| `varactor_cell.net` | KiCad-exported netlist (checked against the design: 303/303 connections) |
| `gen.py`, `libtool.py`, `verify.py` | Schematic generator and netlist checker |
| `sim/` | Behavioural models used to develop the design |

## How it works (signal path)
1. **Input (U1).** Produces +x/2 and -x/2. Input up to about 3.5 V peak.
2. **Modulator (U7, U8).** Two DG419 switches swap +x/2 and -x/2 at the 102.4 kHz carrier (CLK_S). Stack A gets +x·s/2 and stack B gets -x·s/2.
3. **Varactor bridge.**
   - Each stack is an anti-series pair: a diode from the input node to the floating centre, and a diode from the centre to the charge-amp input VG. Each "diode" is two MV2109s in parallel.
   - The centres CA and CB are biased through high-value resistors:
     - VA is fixed (about 4 V) and sets the null.
     - VB is the gain control.
   - Output charge is proportional to (C_A - C_B)·x. Gain is zero at the null (VB ≈ VA) and about 0 dB at VB ≈ 13 V.
4. **Charge amplifier (U2A, OPA1656).** Cf = 6.8 pF, with 100 MΩ for DC.
5. **Synchronous demodulator.**
   - U2B inverts the charge-amp output; U9 selects VO or VO_N in step with the carrier.
   - U10 is a gated hold: it only tracks in the 50–94% window of each half-period, so switching edges are blanked.
6. **30 kHz 4th-order Butterworth (U3B, U4A) and makeup gain (U4B, RV4).**
7. **Timing.** 3.2768 MHz oscillator into a 74HC4040. Q4 is the carrier. GATE = Q3·NOT(Q2·Q1·Q0), decoded by the 74HC10.
8. **Control.** VB = 2·CV + 2·VOFF. CV comes from J4 (0–5 V) or the manual pot RV2, selected by JP1. VOFF (RV3) sets VB = 3 V at CV = 0.

## Differences from the simulated design
v1 is simplified for a first build:
- **Bias feed:** stack B is fed through a 10 MΩ or 100 MΩ resistor (JP2), not the charge-controlled current source with servo. Stack A is fed through 100 MΩ.
- **Bias range:** VB is limited to 3–13 V so everything runs from ±15 V. The simulated design used up to 28 V.
- **Carrier and gate:** 102.4 kHz with a 50–94% gate (simulation: 100 kHz, 40–95%).

## Expected performance
These are estimates from the simulations, not measurements.

| Condition (1 kHz, about 2 V input) | 0 dB | -20 dB | -40 dB |
|---|---|---|---|
| THD, B feed 10 MΩ (JP2 = 1-2) | ~0.004% | ~0.03% | ~0.3% |
| THD, B feed 100 MΩ (JP2 = 2-3) | ~0.004% | ~0.005% | ~0.03% |

- **Gain-control response:** about 1.5 ms with 10 MΩ, about 15 ms with 100 MΩ.
- **Noise:** about -104 dBu, 20 Hz–20 kHz.

The resistor feed is the main limitation in deep attenuation. Version 2 replaces it with the charge-controlled bias, which simulated at about 0.006% at -40 dB.

## Construction
- **High-impedance nodes (VG, CA, CB).** Do not use a solderless breadboard; its leakage is comparable to 10–100 MΩ. Build these nodes in the air on PTFE standoffs (or on clean perfboard with the flux removed), keep the wiring short, and add a guard ring tied to GND around VG if you can.
- **Varactors.**
  - Use MV2109-class abrupt-junction parts (about 33 pF at 4 V, grading exponent about 0.45–0.5). Check availability and the leakage spec: below about 100 pA at 15 V is wanted.
  - Match them by measuring each one's capacitance at 4 V reverse bias, and pair within 1%.
  - Mount all eight on one small thermal block, or glue them together, so they share a temperature.
- **Trimmers.** Fit one trimmer per stack, across whichever diode measures smaller (CT1 or CT2, CT3 or CT4). Use 0.5–3 pF parts, NP0 or PTFE.
- **Parts to check against their datasheets before building:**
  - DG419 pinout. The schematic assumes pin 1 = common, pins 2 and 8 = throws, pin 6 = IN.
  - OPA1656 is SOIC-8; use an SOIC-to-DIP adapter.
  - The oscillator can's pinout (14 = Vcc, 7 = GND, 8 = OUT).

## Bring-up
1. **Power.** Apply ±15 V with no ICs fitted, then check +5 V. Fit the ICs.
2. **Timing.**
   - TP1 (CLK_S) should be a 102.4 kHz square wave.
   - TP2 (GATE) should be high for about 2.1 µs in each 4.88 µs half-period, late in the half-period.
3. **JP3 (hold polarity).** Feed a 1 kHz tone and look at TP6 (HOLD). Pick the JP3 position where HOLD is a clean staircase that follows the audio, with no spikes at the carrier edges.
4. **Stack A bias.** Adjust RV1 for VA_F (TP8) = 4.0 V.
5. **Bias offset.** With CV = 0 (JP1 on manual, RV2 at minimum), adjust RV3 for VB (TP9) = 3.0 V.
6. **Find the null.** Feed 1 kHz at 1 Vrms and slowly raise RV2: the output passes through a deep minimum. That's the null, near VB ≈ VA. Above it, gain rises to about 0 dB at VB ≈ 13 V.
7. **Trim.**
   - Set the gain about 40 dB below maximum (just above the null).
   - Watch THD on an FFT, for example an audio interface with REW.
   - Adjust the fitted trimmers for minimum distortion. Expect the optimum at roughly 70% of the measured capacitance difference.
8. **Calibrate.** Record VB against gain at a few points. That table is what the sidechain (DSP or analog) will use to drive CV.
