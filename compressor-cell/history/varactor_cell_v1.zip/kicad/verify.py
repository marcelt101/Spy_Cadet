import re, sys
sys.argv=['gen.py']; import importlib.util
spec=importlib.util.spec_from_file_location("g","gen.py"); g=importlib.util.module_from_spec(spec)
import io,contextlib
with contextlib.redirect_stdout(io.StringIO()): spec.loader.exec_module(g)
t=open("varactor_cell.net").read()
kic={}; netsize={}
for m in re.finditer(r'\(net \(code "?\d+"?\) \(name "([^"]*)"\)(.*?)\)\s*(?=\(net |\)\s*\)\s*$)',t,re.S):
    name=m.group(1).lstrip('/')
    nodes=re.findall(r'\(node \(ref "([^"]+)"\) \(pin "([^"]+)"\)',m.group(2))
    netsize[name]=len(nodes)
    for r,p in nodes: kic[(r,p)]=name
want={}
for p in g.parts:
    for u,mp in p['units'].items():
        for pin,net in mp.items(): want[(p['ref'],pin)]=net
bad=[(k,v,kic.get(k)) for k,v in want.items() if kic.get(k)!=v]
print(f"intended connections: {len(want)}, KiCad netlist matches: {len(want)-len(bad)}, mismatches: {len(bad)}")
for b in bad[:20]: print("  MISMATCH",b)
extra=[k for k in kic if k not in want and not k[0].startswith('#')]
unc=[k for k,v in kic.items() if v.startswith('unconnected')]
print("pins KiCad reports unconnected:",len(unc), unc[:12])
singles=[n for n,c in netsize.items() if c<2 and not n.startswith('unconnected')]
print("nets with a single connection:",singles)
# power-pin sanity: every power_in pin on a net with a source
from libtool import pins
pw=[]
for p in g.parts:
    P=pins(p['lib'],p['sym'])
    for u,mp in p['units'].items():
        for (num,nm,typ,*_) in P.get(u,[])+P.get(0,[]):
            if typ=="power_in": pw.append((p['ref'],num,mp.get(num)))
print("power pins:",len(pw),"on nets:",sorted(set(n for *_,n in pw)))
