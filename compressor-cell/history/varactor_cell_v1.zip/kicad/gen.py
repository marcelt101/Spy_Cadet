"""Generate KiCad 7 schematic for the varactor-bridge gain cell (prototype v1)."""
import uuid, math, sys
from libtool import flat_symbol, pins
U=lambda: str(uuid.uuid4())
ROOT=U(); PROJ="varactor_cell"
FP=dict(R="Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal",
        C="Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm",
        CF="Capacitor_THT:C_Rect_L7.2mm_W5.5mm_P5.00mm_FKS2_FKP2_MKS2_MKP2",
        CP="Capacitor_THT:CP_Radial_D5.0mm_P2.00mm",
        DIP8="Package_DIP:DIP-8_W7.62mm", DIP14="Package_DIP:DIP-14_W7.62mm", DIP16="Package_DIP:DIP-16_W7.62mm",
        SO8="Package_SO:SOIC-8_3.9x4.9mm_P1.27mm", OSC="Oscillator:Oscillator_DIP-14",
        TO92="Package_TO_SOT_THT:TO-92_Inline", TO92_2="Package_TO_SOT_THT:TO-92-2",
        TRIM="Potentiometer_THT:Potentiometer_Bourns_3296W_Vertical", POT="Potentiometer_THT:Potentiometer_Alps_RK09K_Single_Vertical",
        CTRIM="Capacitor_SMD:C_Trimmer_Voltronics_JR", H2="Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical",
        H3="Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical", TP="TestPoint:TestPoint_Pad_D1.5mm")
parts=[]   # dict(ref,lib,sym,value,fp,units={unit:{pin:net}},pos={unit:(x,y)},nc=[pins],note)
def add(ref,lib,sym,value,fp,units,pos,nc=(),note=""):
    parts.append(dict(ref=ref,lib=lib,sym=sym,value=value,fp=fp,units=units,pos=pos,nc=list(nc),note=note))
texts=[]
def text(s,x,y,size=2.5): texts.append((s,x,y,size))
COLX=[25.4,431.8]; CURY=[40.64,40.64]; _open=[None]
def block(title,col,cols=7,dx=30.48,dy=33.02,sub=None):
    if _open[0]: end()
    x=COLX[col]; y=CURY[col]; text(title,x,y)
    if sub: text(sub,x,y+6,1.8)
    g=Grid(x+10,y+(30 if sub else 26),dx=dx,dy=dy,cols=cols); g.col=col; _open[0]=g; return g
def end():
    g=_open[0]; rows=(g.i+g.cols-1)//g.cols
    CURY[g.col]=g.y0+rows*g.dy+12.7; _open[0]=None

# ---------------- block placement helpers ----------------
class Grid:
    def __init__(s,x0,y0,dx=30.48,dy=27.94,cols=6): s.x0,s.y0,s.dx,s.dy,s.cols,s.i=x0,y0,dx,dy,cols,0
    def next(s):
        c=s.i%s.cols; r=s.i//s.cols; s.i+=1
        return (round((s.x0+c*s.dx)/2.54)*2.54, round((s.y0+r*s.dy)/2.54)*2.54)
def R(ref,val,a,b,g,fp="R"): add(ref,"Device","R",val,FP[fp],{1:{"1":a,"2":b}},{1:g.next()})
def C(ref,val,a,b,g,fp="C"): add(ref,"Device","C" if fp!="CP" else "C_Polarized",val,FP[fp],{1:{"1":a,"2":b}},{1:g.next()})
def OPAMP(ref,val,fp,A,B,g,pw=("+15V","-15V")):
    """A,B: (plus, minus, out)"""
    add(ref,"Amplifier_Operational","OPA2134",val,FP[fp],
        {1:{"3":A[0],"2":A[1],"1":A[2]},2:{"5":B[0],"6":B[1],"7":B[2]},3:{"8":pw[0],"4":pw[1]}},
        {1:g.next(),2:g.next(),3:g.next()})
def DG419(ref,com,s2,s8,inp,g,nc=()):
    add(ref,"Analog_Switch","DG419LDJ","DG419DJ",FP["DIP8"],
        {1:{k:v for k,v in {"1":com,"2":s2,"8":s8,"6":inp}.items() if v},2:{"3":"GND","4":"+15V","5":"+5V","7":"-15V"}},
        {1:g.next(),2:g.next()},nc=nc)

# ================= 1. INPUT & PHASE SPLITTER =================
g=block("1  INPUT: x/2 and -x/2 (input up to ~3.5 Vpk)",0)
add("J2","Connector_Generic","Conn_01x02","AUDIO IN",FP["H2"],{1:{"1":"AUD_IN","2":"GND"}},{1:g.next()})
R("R1","100k","AUD_IN","GND",g)
R("R2","20k","AUD_IN","U1A_N",g); R("R3","10k","U1A_N","XN",g)
R("R4","10k","XN","U1B_N",g); R("R5","10k","U1B_N","XP",g)
OPAMP("U1","OPA2134PA","DIP8",("GND","U1A_N","XN"),("GND","U1B_N","XP"),g)
C("C1","100n","+15V","GND",g); C("C2","100n","-15V","GND",g)

# ================= 2. CLOCK / TIMING =================
g=block("2  TIMING: 3.2768 MHz/32 = 102.4 kHz carrier (CLK_S); GATE = phase 8..14 of 16 per half-period",0)
add("X1","Oscillator","ACO-xxxMHz","3.2768MHz",FP["OSC"],{1:{"14":"+5V","7":"GND","8":"CLK_M"}},{1:g.next()},nc=["1"])
add("U11","4xxx","4040","74HC4040",FP["DIP16"],
    {1:{"10":"CLK_M","11":"GND","16":"+5V","8":"GND","9":"Q0","7":"Q1","6":"Q2","5":"Q3","3":"CLK_S"}},{1:g.next()},
    nc=["2","4","13","12","14","15","1"])
add("U12","74xx","74LS10","74HC10",FP["DIP14"],
    {1:{"1":"Q0","2":"Q1","13":"Q2","12":"NQ012"},2:{"3":"Q3","4":"NQ012","5":"+5V","6":"GATE_N"},
     3:{"9":"GATE_N","10":"+5V","11":"+5V","8":"GATE"},4:{"14":"+5V","7":"GND"}},
    {1:g.next(),2:g.next(),3:g.next(),4:g.next()})
add("JP3","Jumper","Jumper_3_Open","HOLD POLARITY",FP["H3"],{1:{"1":"GATE","2":"HOLD_IN","3":"GATE_N"}},{1:g.next()})
C("C3","100n","+5V","GND",g); C("C4","100n","+5V","GND",g); C("C5","100n","+5V","GND",g)
for i,(n,net) in enumerate([("TP1","CLK_S"),("TP2","GATE"),("TP3","HOLD_IN")]):
    add(n,"Connector","TestPoint",net,FP["TP"],{1:{"1":net}},{1:g.next()})

# ================= 3. MODULATOR =================
g=block("3  MODULATOR: chops +/-x/2 at the carrier (stack A gets +x*s/2, stack B gets -x*s/2)",0)
DG419("U7","SWA","XP","XN","CLK_S",g)
DG419("U8","SWB","XN","XP","CLK_S",g)
R("R6","1k","SWA","XA",g); R("R7","1k","SWB","XB",g)
for i,c in enumerate(["C6","C7","C8","C9"]): C(c,"100n","+15V" if i%2==0 else "-15V","GND",g)
C("C10","100n","+5V","GND",g); C("C11","100n","+5V","GND",g)

# ================= 4. VARACTOR BRIDGE + CHARGE AMP =================
g=block("4  VARACTOR BRIDGE + CHARGE AMP  (guard VG, CA, CB: PTFE standoffs, no solderless breadboard)",1,cols=8,dx=27.94,sub="Fit ONE trimmer per stack, across the smaller-capacitance diode (CT1 or CT2; CT3 or CT4). Trim for minimum THD at -40 dB.")
for i,ref in enumerate(["D1","D2"]): add(ref,"Device","D_Capacitance","MV2109",FP["TO92_2"],{1:{"1":"CA","2":"XA"}},{1:g.next()})
for i,ref in enumerate(["D3","D4"]): add(ref,"Device","D_Capacitance","MV2109",FP["TO92_2"],{1:{"1":"CA","2":"VG"}},{1:g.next()})
for i,ref in enumerate(["D5","D6"]): add(ref,"Device","D_Capacitance","MV2109",FP["TO92_2"],{1:{"1":"CB","2":"XB"}},{1:g.next()})
for i,ref in enumerate(["D7","D8"]): add(ref,"Device","D_Capacitance","MV2109",FP["TO92_2"],{1:{"1":"CB","2":"VG"}},{1:g.next()})
for ref,a,b in [("CT1","XA","CA"),("CT2","CA","VG"),("CT3","XB","CB"),("CT4","CB","VG")]:
    add(ref,"Device","C_Trim","0.5-3pF trimmer",FP["CTRIM"],{1:{"1":a,"2":b}},{1:g.next()})
add("R23","Device","R","100M",FP["R"],{1:{"1":"VA_F","2":"CA"}},{1:g.next()})
R("RB1","10M","VB","RBSEL_10M",g); R("RB2","100M","VB","RBSEL_100M",g)
add("JP2","Jumper","Jumper_3_Open","B FEED 10M/100M",FP["H3"],{1:{"1":"RBSEL_10M","2":"CB","3":"RBSEL_100M"}},{1:g.next()})
C("C38","6.8p C0G","VG","VO",g); R("R24","100M","VG","VO",g)
R("R8","1k","VO","U2B_N",g); R("R9","1k","U2B_N","VO_N",g)
OPAMP("U2","OPA1656ID","SO8",("GND","VG","VO"),("GND","U2B_N","VO_N"),g)
C("C12","100n","+15V","GND",g); C("C13","100n","-15V","GND",g)
add("TP4","Connector","TestPoint","VO",FP["TP"],{1:{"1":"VO"}},{1:g.next()})

# ================= 5. DEMODULATOR, HOLD, LPF, OUTPUT =================
g=block("5  SYNC DEMOD (U9) + GATED HOLD (U10, blanks carrier edges) + 30 kHz 4th-order Butterworth + makeup gain",1,cols=8,dx=27.94,dy=38.1)
DG419("U9","DEM","VO","VO_N","CLK_S",g)
DG419("U10","HOLD","DEM",None,"HOLD_IN",g,nc=["8"])
C("C39","1n C0G","HOLD","GND",g)
R("R10","4.87k","HB","SK1_N1",g); R("R11","4.87k","SK1_N1","SK1_P",g)
C("C14","1.2n C0G","SK1_N1","F1",g); C("C15","1n C0G","SK1_P","GND",g)
R("R12","4.22k","F1","SK2_N1",g); R("R13","4.22k","SK2_N1","SK2_P",g)
C("C16","3.3n C0G","SK2_N1","F2",g); C("C17","470p C0G","SK2_P","GND",g)
OPAMP("U3","OPA2134PA","DIP8",("HOLD","HB","HB"),("SK1_P","F1","F1"),g)
OPAMP("U4","OPA2134PA","DIP8",("SK2_P","F2","F2"),("F2","OG_N","OUT_PRE"),g)
R("R14","1k","OG_N","GND",g)
add("RV4","Device","R_Potentiometer","10k MAKEUP",FP["POT"],{1:{"1":"OUT_PRE","2":"OG_N","3":"OG_N"}},{1:g.next()})
R("R15","100","OUT_PRE","AUD_OUT",g)
add("J3","Connector_Generic","Conn_01x02","AUDIO OUT",FP["H2"],{1:{"1":"AUD_OUT","2":"GND"}},{1:g.next()})
for i,c in enumerate(["C18","C19","C20","C21","C22","C23","C24","C25"]):
    C(c,"100n",["+15V","-15V"][i%2] if i<4 else (["+15V","-15V"][i%2]),"GND",g)
C("C26","100n","+5V","GND",g); C("C27","100n","+5V","GND",g)
for n,net in [("TP5","DEM"),("TP6","HOLD"),("TP7","F2")]:
    add(n,"Connector","TestPoint",net,FP["TP"],{1:{"1":net}},{1:g.next()})

# ================= 6. BIAS & CONTROL =================
g=block("6  BIAS: VA fixed (~4 V, sets null). VB = 2*CV + 2*VOFF  (VOFF ~1.5 V -> VB 3..13 V for CV 0..5 V)",1,cols=9,dx=33.02)
R("R16","4.7k","+15V","REF5",g)
add("U15","Reference_Voltage","LM4040LP-5","LM4040DIZ-5.0",FP["TO92"],{1:{"2":"REF5","3":"GND"}},{1:g.next()})
C("C28","1u","REF5","GND",g,fp="CF")
add("RV1","Device","R_Potentiometer_Trim","10k A-BIAS/NULL",FP["TRIM"],{1:{"1":"REF5","2":"VA_SET","3":"GND"}},{1:g.next()})
add("RV3","Device","R_Potentiometer_Trim","10k VB-OFFSET",FP["TRIM"],{1:{"1":"REF5","2":"VOFF_SET","3":"GND"}},{1:g.next()})
OPAMP("U5","OPA2134PA","DIP8",("VA_SET","VA","VA"),("VOFF_SET","VOFF","VOFF"),g)
R("R17","10k","VA","VA_F",g); C("C29","1u","VA_F","GND",g,fp="CF")
add("J4","Connector_Generic","Conn_01x02","CV IN 0-5V",FP["H2"],{1:{"1":"CV_EXT","2":"GND"}},{1:g.next()})
R("R18","100k","CV_EXT","GND",g)
add("RV2","Device","R_Potentiometer","10k MANUAL GAIN",FP["POT"],{1:{"1":"REF5","2":"CV_MAN","3":"GND"}},{1:g.next()})
add("JP1","Jumper","Jumper_3_Open","CV SOURCE",FP["H3"],{1:{"1":"CV_EXT","2":"CV","3":"CV_MAN"}},{1:g.next()})
R("R19","10k","CV","SUM_P",g); R("R20","10k","VOFF","SUM_P",g)
R("R21","10k","SUM_N","GND",g); R("R22","30.1k","SUM_N","VB",g)
OPAMP("U6","OPA2134PA","DIP8",("SUM_P","SUM_N","VB"),("GND","U6B_O","U6B_O"),g)
for c,n in [("C30","+15V"),("C31","-15V"),("C32","+15V"),("C33","-15V")]: C(c,"100n",n,"GND",g)
for n,net in [("TP8","VA_F"),("TP9","VB")]:
    add(n,"Connector","TestPoint",net,FP["TP"],{1:{"1":net}},{1:g.next()})

# ================= 7. POWER =================
g=block("7  POWER: +/-15 V bench supply; +5 V for logic and DG419 VL",0)
add("J1","Connector_Generic","Conn_01x03","+15 / GND / -15",FP["H3"],{1:{"1":"+15V","2":"GND","3":"-15V"}},{1:g.next()})
C("C34","10u","+15V","GND",g,fp="CP"); C("C35","10u","GND","-15V",g,fp="CP")
add("U14","Regulator_Linear","L78L05_TO92","78L05",FP["TO92"],{1:{"3":"+15V","2":"GND","1":"+5V"}},{1:g.next()})
C("C36","330n","+15V","GND",g); C("C37","1u","+5V","GND",g,fp="CF")
for i,net in enumerate(["+15V","-15V","GND"]):
    add(f"#FLG0{i+1}","power","PWR_FLAG","PWR_FLAG","",{1:{"1":net}},{1:g.next()})

end()
# ======================= writer =======================
def q(s): return '"'+str(s).replace('\\','\\\\').replace('"','\\"')+'"'
STUB=2.54
out=[]; libs={}
def eff(hide=False,j=None,size=1.27):
    s=f"(effects (font (size {size} {size}))"+(f" (justify {j})" if j else "")+(" hide" if hide else "")+")"
    return s
labels_at=set()
for p in parts:
    key=f"{p['lib']}:{p['sym']}"
    if key not in libs: libs[key]=flat_symbol(p['lib'],p['sym'])
    P=pins(p['lib'],p['sym'])
    is_pwr = p['lib']=="power"
    for unit,(X,Y) in p['pos'].items():
        mapping=p['units'].get(unit,{})
        upins=P.get(unit,[])+P.get(0,[])
        props=[("Reference",p['ref'],(X+2.54,Y-8.0),False),("Value",p['value'],(X+2.54,Y+9.0),is_pwr),
               ("Footprint",p['fp'],(X,Y+12),True),("Datasheet","~",(X,Y+12),True)]
        s=[f'(symbol (lib_id {q(key)}) (at {X:.2f} {Y:.2f} 0) (unit {unit}) (in_bom {"no" if is_pwr else "yes"}) (on_board {"no" if is_pwr else "yes"}) (dnp no) (uuid {U()})']
        for name,val,(px,py),hide in props:
            s.append(f'  (property {q(name)} {q(val)} (at {px:.2f} {py:.2f} 0) {eff(hide,"left" if name in("Reference","Value") else None)})')
        for (num,nm,typ,x,y,a) in upins:
            s.append(f'  (pin {q(num)} (uuid {U()}))')
        s.append(f'  (instances (project {q(PROJ)} (path "/{ROOT}" (reference {q(p["ref"])}) (unit {unit}))))')
        s.append(')'); out.append("\n".join(s))
        for (num,nm,typ,x,y,a) in upins:
            ax,ay=X+x,Y-y
            if num in mapping:
                net=mapping[num]
                dx,dy=-math.cos(math.radians(a)),math.sin(math.radians(a))   # outward, schematic coords (y down)
                ex,ey=ax+dx*STUB,ay+dy*STUB
                out.append(f'(wire (pts (xy {ax:.2f} {ay:.2f}) (xy {ex:.2f} {ey:.2f})) (stroke (width 0) (type default)) (uuid {U()}))')
                ang={(1,0):0,(0,-1):90,(-1,0):180,(0,1):270}[(round(dx),round(dy))]
                just="left bottom" if ang in (0,90) else "right bottom"
                out.append(f'(label {q(net)} (at {ex:.2f} {ey:.2f} {ang}) (fields_autoplaced) {eff(j=just)} (uuid {U()}))')
            elif num in p['nc'] or typ=="no_connect":
                out.append(f'(no_connect (at {ax:.2f} {ay:.2f}) (uuid {U()}))')
            else:
                print(f"WARNING unconnected pin {p['ref']} unit{unit} pin{num} ({nm})")
for s_,x,y,size in texts:
    out.append(f'(text {q(s_)} (at {x:.2f} {y:.2f} 0) (effects (font (size {size} {size}) bold) (justify left bottom)) (uuid {U()}))')
notes=["VARACTOR-BRIDGE GAIN CELL  -  breadboard prototype v1 (unverified design: build & measure)",
"Gain law: output = (C_A - C_B)/(2*Cf) * input, set by VB vs VA. Null (max attenuation) at VB ~ VA; 0 dB at VB ~ 13 V.",
"Bring-up: 1) check CLK_S 102.4 kHz, GATE window;  2) set JP3 so HOLD (TP6) is flat across carrier edges;",
"3) RV1: set VA ~ 4.0 V;  4) RV3: VB = 3.0 V at CV = 0;  5) find null with RV2 (min output), trim CT for min THD at -40 dB.",
"High-impedance nodes VG, CA, CB: keep off solderless breadboard (leakage). Use PTFE standoffs/air wiring, clean flux.",
"Varactors: MV2109-class abrupt-junction (grading ~0.45-0.5), ~33 pF @ 4 V. Match by selection (<1%) and keep thermally coupled."]
for i,s_ in enumerate(notes):
    out.append(f'(text {q(s_)} (at 25.4 {CURY[0]+10+i*7:.2f} 0) (effects (font (size 2 2)) (justify left bottom)) (uuid {U()}))')
doc=[f'(kicad_sch (version 20230121) (generator eeschema)',f'(uuid {ROOT})','(paper "A1")',
     '(title_block (title "Varactor-bridge gain cell - prototype v1") (date "2026-11-13") (rev "0.1") (comment 1 "Carrier-fed anti-series varactor bridge + charge amp + sync demod"))',
     '(lib_symbols']+[libs[k] for k in libs]+[')']+out+['(sheet_instances (path "/" (page "1")))',')']
open(f"{PROJ}.kicad_sch","w").write("\n".join(doc))
import json
open(f"{PROJ}.kicad_pro","w").write(json.dumps({"meta":{"filename":f"{PROJ}.kicad_pro","version":1},"schematic":{"legacy_lib_dir":"","legacy_lib_list":[]},"sheets":[[ROOT,""]]},indent=2))
# BOM
from collections import defaultdict
bom=defaultdict(list)
for p in parts:
    if p['lib']=="power": continue
    bom[(p['value'],p['sym'],p['fp'])].append(p['ref'])
with open("BOM.csv","w") as f:
    f.write("Qty,References,Value,Symbol,Footprint\n")
    for (v,s_,fp),refs in sorted(bom.items(),key=lambda kv:kv[1][0]):
        f.write(f'{len(refs)},"{" ".join(refs)}","{v}",{s_},{fp}\n')
print("parts:",len([p for p in parts if p['lib']!='power']),"lib symbols:",len(libs))
