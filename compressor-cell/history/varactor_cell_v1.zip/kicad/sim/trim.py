"""Carrier-fed varactor bridge, charge-controlled bias (servo ~400 MOhm), per-diode params + trimmer caps."""
import sys; sys.path.insert(0,'.')
import numpy as np
from numba import njit
from qmodel import CJO, VJ, VA, VBMAX, FC, SPC, carrier_wave, thd, vb_for_gain, CF

@njit(cache=True)
def Qd(V,cjo,M,vj,ct): return cjo*vj/(1-M)*((1+V/vj)**(1-M)-1)+ct*V
@njit(cache=True)
def Cd(V,cjo,M,vj,ct): return cjo/(1+V/vj)**M+ct

@njit(cache=True)
def centre(Qc,vin,p1,p2,g):
    c=g
    for _ in range(40):
        f=Qd(c-vin,p1[0],p1[1],p1[2],p1[3])+Qd(c,p2[0],p2[1],p2[2],p2[3])-Qc
        dc=f/(Cd(c-vin,p1[0],p1[1],p1[2],p1[3])+Cd(c,p2[0],p2[1],p2[2],p2[3])); c-=dc
        if abs(dc)<1e-15: break
    return c

@njit(cache=True)
def run(vin, VBa, VBb, dt, R, Rleak, A1, A2, B1, B2, Cf):
    n=len(vin); out=np.empty(n); ca=VBa; cb=VBb
    QA=Qd(ca,A1[0],A1[1],A1[2],A1[3])+Qd(ca,A2[0],A2[1],A2[2],A2[3])
    QB=Qd(cb,B1[0],B1[1],B1[2],B1[3])+Qd(cb,B2[0],B2[1],B2[2],B2[3])
    q0=Qd(ca,A2[0],A2[1],A2[2],A2[3])+Qd(cb,B2[0],B2[1],B2[2],B2[3])
    for i in range(n):
        a=0.5*vin[i]; b=-a
        QA+=((VBa-ca)/R-((ca-a)+ca)/Rleak)*dt; QB+=((VBb-cb)/R-((cb-b)+cb)/Rleak)*dt
        ca=centre(QA,a,A1,A2,ca); cb=centre(QB,b,B1,B2,cb)
        out[i]=(Qd(ca,A2[0],A2[1],A2[2],A2[3])+Qd(cb,B2[0],B2[1],B2[2],B2[3])-q0)/Cf
    return out

def dio(scale=1.0,M=0.5,vj=VJ,ct=0.0): return np.array([CJO*scale,M,vj,ct])
def measure(g,vrms,A1,A2,B1,B2,f0=1000.0,R=4e8):
    T=8/f0; fs=FC*SPC; n=int(round(T*FC))*SPC; t=np.arange(n)/fs
    s=carrier_wave(n); x=vrms*np.sqrt(2)*np.sin(2*np.pi*f0*t)
    y=run(x*s,VA,vb_for_gain(g),1/fs,R,1e11,A1,A2,B1,B2,CF)*s
    yb=y.reshape(-1,SPC).mean(1)/np.mean(np.abs(s)); a,d=thd(yb,FC,f0,4); return d

if __name__=="__main__":
    Cop=CJO/(1+VA/VJ)**0.5
    print(f"diode C at {VA} V bias = {Cop*1e12:.0f} pF; 1% mismatch = {0.01*Cop*1e12:.2f} pF")
    nom=dio()
    print("\n1) 1% CJO mismatch in BOTH pairs, trimmer on the smaller diode of each pair (B trimmed at its -40 dB bias)")
    Cb=CJO/(1+vb_for_gain(-40)/VJ)**0.5
    for frac in [0,0.5,0.9,1.0,1.1,1.5]:
        tA=frac*0.01*Cop; tB=frac*0.01*Cb
        r=[f"{measure(g,v,dio(1.01),dio(ct=tA),dio(1.01),dio(ct=tB))*100:.4f}%" for v in (2,7) for g in (0,-20,-40)]
        print(f"  trim {frac*100:4.0f}% of ideal ({tA*1e12:.2f} pF): 2V 0/-20/-40: {' / '.join(r[:3])}   7V: {' / '.join(r[3:])}")
    print("\n2) shape mismatch the trimmer cannot fully fix: grading M 0.50 vs 0.49 in each pair")
    for frac in [0,1.0]:
        # equalise capacitance at bias: C(M=0.49) is larger -> trim the M=0.50 diode
        dA=CJO/(1+VA/VJ)**0.49-Cop; Vb=vb_for_gain(-40); dB=CJO/(1+Vb/VJ)**0.49-CJO/(1+Vb/VJ)**0.5
        r=[f"{measure(g,2,dio(M=0.49),dio(ct=frac*dA),dio(M=0.49),dio(ct=frac*dB))*100:.4f}%" for g in (0,-20,-40)]
        print(f"  {'untrimmed' if frac==0 else f'trimmed ({dA*1e12:.2f} pF)'}: 2V 0/-20/-40: {' / '.join(r)}")
    print("\n3) reference: perfectly matched, no trim")
    r=[f"{measure(g,v,nom,nom,nom,nom)*100:.4f}%" for v in (2,7) for g in (0,-20,-40)]
    print(f"  2V: {' / '.join(r[:3])}   7V: {' / '.join(r[3:])}")
