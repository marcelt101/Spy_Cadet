import sys; sys.path.insert(0,'.')
from real import *
import time
def tone_test(g,vrms,f0=1000.0,diodes=None,ncyc=10):
    diodes=diodes or make_diodes()
    n=int(ncyc/f0*FS); t=np.arange(n)/FS
    x=vrms*np.sqrt(2)*np.sin(2*np.pi*f0*t); y=simulate(x,np.full(n,g),diodes)
    fs2=2*FC; m=int(round(4*fs2/f0)); seg=y[-m:]
    Y=np.abs(np.fft.rfft(seg)); fr=np.fft.rfftfreq(len(seg),1/fs2)
    def amp(f): return Y[int(round(f/(fr[1]-fr[0])))]
    h1=amp(f0); hs=[amp(k*f0) for k in range(2,10) if k*f0<20e3]
    return h1, np.sqrt(sum(h*h for h in hs))/h1, [h/h1 for h in hs]
t0=time.time()
vbs,sg=calibrate(make_diodes()); i=np.argmin(abs(sg)); print(f"null (gain 0) at bias {vbs[i]:.4f} V vs A {VA} V; deepest |gain| on grid {20*np.log10(abs(sg[i])+1e-9):.1f} dB")
ref,_,_=tone_test(1.0,0.1)
print(f"Cf={CF*1e12:.1f} pF, A bias {VA} V, servo-equivalent R {RSERVO/1e6:.0f} MOhm")
print("THD at 1 kHz (trimmed, 1%/0.8% raw mismatch), gain re small-signal 0 dB:")
for gdb in [0,-20,-40]:
    r=[]
    for v in [0.5,1.5,2.5]:
        h1,d,hs=tone_test(10**(gdb/20),v)
        r.append(f"{v}Vrms: gain {20*np.log10(h1/ref*0.1/v):6.2f} THD {d*100:.4f}% (H2 {hs[0]*100:.4f} H3 {hs[1]*100:.4f})")
    print(f"  {gdb:4d} dB | "+" | ".join(r))
for f0 in [50.0,10000.0]:
    h1,d,hs=tone_test(10**(-20/20),1.5,f0=f0,ncyc=10 if f0>100 else 6)
    print(f"  -20 dB, 1.5 Vrms, {f0:.0f} Hz: THD {d*100:.4f}%")
# noise: zero input
for gdb in [0,-40]:
    n=int(0.2*FS); y=simulate(np.zeros(n),np.full(n,10**(gdb/20)),make_diodes())
    y=y[len(y)//4:]; fs2=2*FC
    Y=np.fft.rfft(y*np.hanning(len(y))); fr=np.fft.rfftfreq(len(y),1/fs2)
    P=np.abs(Y)**2/np.sum(np.hanning(len(y))**2)*2/fs2
    band=(fr>20)&(fr<20e3); vn=np.sqrt(np.sum(P[band])*(fr[1]-fr[0]))
    resid=np.sqrt(np.sum(P[fr>=20e3])*(fr[1]-fr[0]))
    print(f"  noise at {gdb} dB: {20*np.log10(vn/0.775):.1f} dBu (20-20k); above-band residue {20*np.log10(resid/0.775+1e-30):.1f} dBu")
print(f"({time.time()-t0:.0f} s)")
