import numpy as np, subprocess, os, re
D=os.path.dirname(os.path.abspath(__file__))
CJO=500e-12; VJ=0.7; VA=5.0; VBMAX=40.0
def cd(V,M=0.5): return CJO/(1+V/VJ)**M
DCMAX=(cd(VA)-cd(VBMAX))/2          # stack = two diodes in series
CF=DCMAX/2                          # 0 dB at max imbalance
def vb_for_gain(gdb,M=0.5):
    """solve stack-B bias giving (C_A-C_B)/(2Cf) = 10^(g/20)"""
    target=10**(gdb/20)*2*CF*2      # diode-level delta C
    lo,hi=VA,VBMAX
    for _ in range(80):
        mid=(lo+hi)/2
        if cd(VA,M)-cd(mid,M)<target: lo=mid
        else: hi=mid
    return (lo+hi)/2
def net(vb,src,M=0.5,MB=None,mis=0.0,rbias="1T",leak=None,opnoise=True,rf="1G"):
    MB=M if MB is None else MB
    lk="" if leak is None else "\n".join(f"RL{n} {a} {b} {leak}" for n,(a,b) in enumerate([("a1","ca"),("vg","ca"),("b1","cb"),("vg","cb")]))
    rn="10" if opnoise else "1m"
    return f"""* varactor bridge gain cell
.model DV  D(IS=1e-15 RS=0.5 CJO={CJO} VJ={VJ} M={M} BV=60)
.model DVM D(IS=1e-15 RS=0.5 CJO={CJO*(1+mis)} VJ={VJ} M={M} BV=60)
.model DVB D(IS=1e-15 RS=0.5 CJO={CJO} VJ={VJ} M={MB} BV=60)
.subckt OA inp inn out
Rn inp ip {rn}
G1 0 x ip inn 1
Rx x 0 1e5
Cx x 0 1.6n
E1 out 0 x 0 1
.ends
{src}
EA a1 0 in 0 0.5
EB b1 0 in 0 -0.5
* stack A: anti-series, cathodes at floating centre ca, biased {VA} V
DA1 a1 ca DVM
DA2 vg ca DV
RBA ca va {rbias}
VCA va 0 {VA}
* stack B, bias vb
DB1 b1 cb DVB
DB2 vg cb DVB
RBB cb vbn {rbias}
VCB vbn 0 {vb}
{lk}
* charge amplifier
XO 0 vg out OA
CF vg out {CF}
RF vg out {rf}
"""
def run(netstr,ctl,tag):
    f=f"{D}/{tag}.cir"; open(f,"w").write(netstr+".control\n"+ctl+"\n.endc\n.end\n")
    r=subprocess.run(["ngspice","-b",f],capture_output=True,text=True); return r.stdout+r.stderr
def thd(gdb,vrms,f0,**kw):
    M=kw.get('M',0.5); vb=vb_for_gain(gdb,M); T=1/f0; vpk=vrms*np.sqrt(2)
    tag=f"t{abs(hash((gdb,vrms,f0,str(kw))))%10**9}"
    out=run(net(vb,f"VIN in 0 SIN(0 {vpk} {f0})",**kw),
        f"option reltol=1e-7 abstol=1e-16 chgtol=1e-18 vntol=1e-9\ntran {T/2000} {6*T} 0 {T/2000}\nlinearize v(out)\nwrdata {D}/{tag}.dat v(out)",tag)
    d=np.loadtxt(f"{D}/{tag}.dat"); tt=np.linspace(2*T,6*T,16384,endpoint=False); vv=np.interp(tt,d[:,0],d[:,1])
    Y=np.abs(np.fft.rfft(vv))/len(vv)*2; h=[Y[4*k] for k in range(1,10)]
    for e in (".cir",".dat"): os.remove(f"{D}/{tag}{e}")
    return 20*np.log10(h[0]/vpk), np.sqrt(sum(x*x for x in h[1:]))/h[0], [x/h[0] for x in h]
