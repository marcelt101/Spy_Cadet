"""Charge-domain model of the varactor bridge cell (ideal charge amp, ideal drivers).
Each stack: D1 (anode=input node, cathode=centre), D2 (anode=virtual ground, cathode=centre).
Centre fed from bias Vc through R; leakage modelled as resistance across each diode."""
import numpy as np
from numba import njit
CJO=500e-12; VJ=0.7; VA=5.0; VBMAX=40.0

@njit(cache=True)
def Q(V,cjo,M):  # junction charge vs reverse voltage V (>0 = reverse)
    return cjo*VJ/(1-M)*((1+V/VJ)**(1-M)-1)
@njit(cache=True)
def C(V,cjo,M): return cjo/(1+V/VJ)**M

@njit(cache=True)
def solve_centre(Qc, vin_node, cjo1, M, guess):
    # find centre voltage c with Q(c-vin)+Q(c)=Qc  (D1 cjo may differ)
    c=guess
    for _ in range(30):
        f=Q(c-vin_node,cjo1,M)+Q(c,CJO,M)-Qc
        df=C(c-vin_node,cjo1,M)+C(c,CJO,M)
        dc=f/df; c-=dc
        if abs(dc)<1e-15: break
    return c

@njit(cache=True)
def run(vin_a, vc_a, vc_b, dt, R, Rleak, cjoA1, MA, MB, Cf):
    n=len(vin_a); out=np.empty(n)
    k=(Rleak/2)/(R+Rleak/2) if Rleak>0 else 1.0
    ca=vc_a[0]*k; cb=vc_b[0]*k
    QA=Q(ca,cjoA1,MA)+Q(ca,CJO,MA); QB=Q(cb,CJO,MB)+Q(cb,CJO,MB)
    q0=Q(ca,CJO,MA)+Q(cb,CJO,MB)
    for i in range(n):
        a=0.5*vin_a[i]; b=-0.5*vin_a[i]
        # centre charge changes only through bias resistor and leakage (trapezoid-free explicit; R current is slow)
        IA=(vc_a[i]-ca)/R; IB=(vc_b[i]-cb)/R
        if Rleak>0:
            IA-=((ca-a)+ca)/Rleak; IB-=((cb-b)+cb)/Rleak
        QA+=IA*dt; QB+=IB*dt
        ca=solve_centre(QA,a,cjoA1,MA,ca)
        cb=solve_centre(QB,b,CJO,MB,cb)
        out[i]=(Q(ca,CJO,MA)+Q(cb,CJO,MB)-q0)/Cf
    return out

def cd(V,M=0.5): return CJO/(1+V/VJ)**M
DCMAX=(cd(VA)-cd(VBMAX))/2; CF=DCMAX/2
def vb_for_gain(g,M=0.5):
    tgt=10**(g/20)*2*CF*2; lo,hi=VA,VBMAX
    for _ in range(80):
        mid=(lo+hi)/2
        if cd(VA,M)-cd(mid,M)<tgt: lo=mid
        else: hi=mid
    return (lo+hi)/2

def thd(y,fs,f0,ncyc):
    n=int(round(ncyc*fs/f0)); seg=y[-n:]; Y=np.abs(np.fft.rfft(seg-seg.mean()))/len(seg)*2
    h=[Y[ncyc*k] for k in range(1,10)]; return h[0],np.sqrt(sum(x*x for x in h[1:]))/h[0]

def baseband(g,f0,vrms,R=1e12,Rleak=0.0,mis=0.0,M=0.5,ncyc=6):
    fs=max(2e6,2000*f0); dt=1/fs; n=int(ncyc*fs/f0); t=np.arange(n)*dt
    x=vrms*np.sqrt(2)*np.sin(2*np.pi*f0*t)
    y=run(x,np.full(n,VA),np.full(n,vb_for_gain(g,M)),dt,R,Rleak,CJO*(1+mis),M,M,CF)
    a,d=thd(y,fs,f0,4); return 20*np.log10(a/(vrms*np.sqrt(2))),d

FC=200e3; SPC=200
def carrier_wave(n,edge=0.02):
    ph=(np.arange(n)%SPC)/SPC
    s=np.where(ph<0.5,1.0,-1.0)
    # finite edges: linear ramps of width edge*period
    w=edge; s=np.where(ph<w/2,ph/(w/2),s); s=np.where((ph>=0.5-w/2)&(ph<0.5+w/2),1-(ph-(0.5-w/2))/(w/2),s)
    s=np.where(ph>=1-w/2,-1+(ph-(1-w/2))/(w/2),s); return s
def carrier(g_or_vb,f0,vrms,T,R=1e6,Rleak=1e11,mis=0.0,M=0.5,vbarr=None):
    fs=FC*SPC; dt=1/fs; n=int(round(T*FC))*SPC; t=np.arange(n)*dt
    s=carrier_wave(n); x=vrms*np.sqrt(2)*np.sin(2*np.pi*f0*t)
    vb=vbarr(t) if vbarr is not None else np.full(n,vb_for_gain(g_or_vb,M))
    y=run(x*s,np.full(n,VA),vb,dt,R,Rleak,CJO*(1+mis),M,M,CF)*s
    yb=y.reshape(-1,SPC).mean(1)/np.mean(np.abs(s))
    return yb
