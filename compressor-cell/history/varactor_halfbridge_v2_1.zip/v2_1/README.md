# Varactor half-bridge gain cell: v2.1 (wired, readable schematic)

Electrically this is v2, redrawn by hand. Every part is wired, net labels are used only where a signal travels between blocks, and every named net describes its purpose.
Connectivity is checked automatically against the verified v2 netlist: 51 of 51 nets match. The only unconnected pins are the intentional no-connects.

## Changes from v2
- **Varactors D1, D2:** onsemi **MMBV2109LT1G** (SOT-23), replacing the obsolete MV2109 (TO-92). The **LV2209** (TO-92, same specification) is a through-hole alternative.
- **Varactor footprints corrected.** KiCad's varactor symbol has pin 1 = cathode, but onsemi packages have pin 1 = anode. The previous footprints would have mounted the diodes backwards. The project library `varactor.pretty` holds renumbered footprints:
  - `Varactor_SOT-23_A1-NC2-K3`: SOT-23 style 8 (1 = anode, 2 = no connect, 3 = cathode)
  - `Varactor_TO-92-2_A1-K2`: TO-92 style 1 (1 = anode, 2 = cathode)
- **JP2 bias feed:** RB1 = 10 MΩ ("NORMAL", about 1.4 ms gain response), RB2 = 3.3 MΩ ("FAST", about 0.5 ms, roughly 2× the distortion).
- **Connector pinouts:**
  - J1: pin 3 = +15 V, pin 2 = GND, pin 1 = -15 V.
  - J2 (audio in): pin 2 = signal, pin 1 = GND.
  - J3 (audio out): pin 1 = signal, pin 2 = GND.
  - J4 (CV in): pin 1 = CV, pin 2 = GND.

## Sheet layout (A1)
- **Top row (signal path, left to right):**
  - 1 Input
  - 3 Modulator
  - 4 Half-bridge + charge amp
  - 5 Demodulator, hold, filter, output
- **Middle row:** 2 Timing, 6 Control
- **Bottom row:** 7 Power, 8 IC supply pins + decoupling

## Net glossary
| Net | Purpose |
|---|---|
| AUDIO_IN / AUDIO_OUT | Cell input and output |
| IN_HALF_NEG / IN_HALF_POS | -x/2 and +x/2 from the input phase splitter |
| CARRIER_102K | 102.4 kHz carrier clock: drives the modulator switches U7 and U8 and the demodulator switch U9 |
| CHOP_REF | Chopped signal feeding the fixed capacitor C40 + CT3 |
| CHOP_VAR | Chopped signal feeding the varactor pair D1 + D2 (opposite phase to CHOP_REF) |
| VAR_BIAS_NODE | Floating centre (cathodes) of the varactor pair; high impedance |
| VAR_BIAS_CMD | Bias command voltage; reaches VAR_BIAS_NODE through RB1 or RB2 (selected by JP2) |
| CHG_AMP_SUM | Charge amplifier summing node (inverting input of U2A); high impedance |
| CHG_AMP_OUT / CHG_AMP_OUT_INV | Charge amplifier output and its inverted copy |
| DEMOD_OUT | Output of the synchronous demodulator (U9) |
| HOLD_CAP / HOLD_BUF | Gated hold capacitor, and its buffered version |
| LPF1_OUT / LPF_OUT | Output of the first filter stage / output of the full 30 kHz filter |
| MAKEUP_OUT | Output of the makeup gain stage |
| CLK_3M2768, CNT_Q0..Q3 | Master clock and counter phase bits |
| HOLD_GATE / HOLD_GATE_N | Hold window (counts 8–14 of each half-period) and its inverse |
| HOLD_SW_CTRL | Hold switch control, selected by JP3 |
| REF_5V | 5 V reference (U15) |
| VB_OFFSET | Bias offset set by RV3 (VAR_BIAS_CMD = 1.5 V at zero CV) |
| GAIN_CV / GAIN_CV_EXT / GAIN_CV_MAN | Selected gain control voltage / from J4 / from the manual pot RV2 |

## Opening in KiCad
Open `varactor_halfbridge.kicad_pro` in KiCad 7 or 8. The project footprint library is registered in `fp-lib-table`.
Run ERC once in the GUI. KiCad 7's command line cannot run ERC, so connectivity was verified through the exported netlist instead.

Construction and bring-up notes are unchanged from v2; see the v2 README.
